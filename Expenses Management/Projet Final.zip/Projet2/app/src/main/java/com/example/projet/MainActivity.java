package com.example.projet;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Typeface;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.EditText;
import android.util.Log;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import android.os.Environment;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    EditText editTextName, editTextCarte, editTextMontant, editTextExpense, editTextBills, editTextMisc;

    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        editTextName = findViewById(R.id.editTextName);
        editTextCarte = findViewById(R.id.editTextCarte);
        editTextMontant = findViewById(R.id.editTextMontant);
        editTextExpense = findViewById(R.id.editTextExpense);
        editTextBills = findViewById(R.id.editTextBills);
        editTextMisc = findViewById(R.id.editTextMisc);

        editTextCarte.setFilters(new InputFilter[]{new InputFilter.LengthFilter(19)});
        editTextMontant.setFilters(new InputFilter[]{new NumbersOnlyFilter()});
        editTextExpense.setFilters(new InputFilter[]{new NumbersOnlyFilter()});
        editTextBills.setFilters(new InputFilter[]{new NumbersOnlyFilter()});
        editTextMisc.setFilters(new InputFilter[]{new NumbersOnlyFilter()});

        CardView cardView = findViewById(R.id.cardView);

        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        ));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);
        cardView.addView(linearLayout);

        TextView carteTextView = new TextView(this);
        carteTextView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        carteTextView.setTextSize(20);
        carteTextView.setTextColor(Color.parseColor("#69E3F6"));
        carteTextView.setTypeface(null, Typeface.BOLD);
        linearLayout.addView(carteTextView);

        TextView montantTextView = new TextView(this);
        montantTextView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        montantTextView.setTextSize(20);
        montantTextView.setTextColor(Color.parseColor("#69E3F6"));
        montantTextView.setTypeface(null, Typeface.BOLD);
        linearLayout.addView(montantTextView);

        editTextCarte.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String formattedText = formatCardNumber(s.toString());
                carteTextView.setText("Carte: " + formattedText);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        editTextMontant.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                RadioGroup radioGroup = findViewById(R.id.radioGroupCurrency);
                int selectedId = radioGroup.getCheckedRadioButtonId();
                String currency = "TND";

                if (selectedId != -1) {
                    RadioButton selectedCurrency = findViewById(selectedId);
                    currency = selectedCurrency.getText().toString();
                }

                montantTextView.setText("Montant: " + s.toString() + " " + currency);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        findViewById(R.id.button).setOnClickListener(v -> saveDataToFileAndDatabase());
    }

    private String formatCardNumber(String input) {
        String digits = input.replaceAll("\\D", "");
        if (digits.length() > 16) {
            digits = digits.substring(0, 16);
        }
        StringBuilder formatted = new StringBuilder();
        for (int i = 0; i < digits.length(); i++) {
            if (i > 0 && i % 4 == 0) {
                formatted.append(" ");
            }
            formatted.append(digits.charAt(i));
        }
        return formatted.toString();
    }

    public class NumbersOnlyFilter implements InputFilter {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            for (int i = start; i < end; i++) {
                if (!Character.isDigit(source.charAt(i))) {
                    return "";
                }
            }
            return null;
        }
    }

    private void saveDataToFileAndDatabase() {
        try {
            int expense = Integer.parseInt(editTextExpense.getText().toString());
            int bills = Integer.parseInt(editTextBills.getText().toString());
            int misc = Integer.parseInt(editTextMisc.getText().toString());
            int totalExpenses = expense + bills + misc;

            int montant = Integer.parseInt(editTextMontant.getText().toString());
            int rest = montant - totalExpenses;

            if (totalExpenses > montant) {
                Toast.makeText(this, "Total expenses exceed Salary", Toast.LENGTH_SHORT).show();
                return;
            }

            File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!directory.exists()) {
                directory.mkdirs();
            }

            File file = new File(directory, "Info_Bank.txt");
            FileWriter writer = new FileWriter(file, true);
            writer.append("Name: ").append(editTextName.getText().toString()).append("\n");
            writer.append("Carte: ").append(editTextCarte.getText().toString()).append("\n");
            writer.append("Montant: ").append(editTextMontant.getText().toString()).append("\n");
            writer.append("Expense: ").append(editTextExpense.getText().toString()).append("\n");
            writer.append("Bills: ").append(editTextBills.getText().toString()).append("\n");
            writer.append("Misc: ").append(editTextMisc.getText().toString()).append("\n");

            if (rest != 0) {
                writer.append("Rest: ").append(String.valueOf(rest)).append("\n");
            }
            writer.append("...").append("\n");

            writer.close();
            Toast.makeText(this, "Data saved to file", Toast.LENGTH_SHORT).show();

            // Insert data into SQLite database
            boolean isInserted = dbHelper.insertData(
                    editTextName.getText().toString(),
                    editTextCarte.getText().toString(),
                    Integer.parseInt(editTextMontant.getText().toString()),
                    Integer.parseInt(editTextExpense.getText().toString()),
                    Integer.parseInt(editTextBills.getText().toString()),
                    Integer.parseInt(editTextMisc.getText().toString())
            );
            if (isInserted) {
                Toast.makeText(this, "Data saved to SQLite database", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to save data to SQLite database", Toast.LENGTH_SHORT).show();
            }


        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numeric values", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Failed to save data", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public class DatabaseHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "BankInfo.db";
        private static final String TABLE_NAME = "BankInfo";
        private static final String COL_1 = "ID";
        private static final String COL_2 = "Name";
        private static final String COL_3 = "Carte";
        private static final String COL_4 = "Montant";
        private static final String COL_5 = "Expense";
        private static final String COL_6 = "Bills";
        private static final String COL_7 = "Misc";

        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "Name TEXT, " +
                    "Carte TEXT, " +
                    "Montant INTEGER, " +
                    "Expense INTEGER, " +
                    "Bills INTEGER, " +
                    "Misc INTEGER)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }

        public boolean insertData(String name, String carte, int montant, int expense, int bills, int misc) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(COL_2, name);
            contentValues.put(COL_3, carte);
            contentValues.put(COL_4, montant);
            contentValues.put(COL_5, expense);
            contentValues.put(COL_6, bills);
            contentValues.put(COL_7, misc);
            long result = db.insert(TABLE_NAME, null, contentValues);
            Log.d("Database Insertion", "Result: " + result); // Add this line for logging
            return result != -1;
        }
    }
}
